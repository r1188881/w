package com.example.mazesolver;

import java.io.IOException;
import java.util.*;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

/**
 * Maze Solver - Forge 1.8.9 client-side mod, everything in one file.
 *
 * Keys (rebindable under Controls > Maze Solver):
 *   Right Shift  open the menu     M  start/stop     G  set goal to looked-at block
 *
 * Menu: ON/OFF toggle, route preview (no walking), set goal, auto-find exit
 * (emerald/gold/diamond block), progress bar and a top-down preview map.
 */
@Mod(modid = "mazesolver", name = "Maze Solver", version = "1.1.0", clientSideOnly = true)
public class MazeSolverMod {
    private final Minecraft mc = Minecraft.getMinecraft();
    private KeyBinding guiKey, toggleKey, goalKey;

    @Mod.EventHandler
    public void init(FMLInitializationEvent e) {
        guiKey    = new KeyBinding("Open Maze Solver menu", Keyboard.KEY_RSHIFT, "Maze Solver");
        toggleKey = new KeyBinding("Start / Stop solver", Keyboard.KEY_M, "Maze Solver");
        goalKey   = new KeyBinding("Set goal (looked-at block)", Keyboard.KEY_G, "Maze Solver");
        ClientRegistry.registerKeyBinding(guiKey);
        ClientRegistry.registerKeyBinding(toggleKey);
        ClientRegistry.registerKeyBinding(goalKey);
        // 1.8.9: tick events live on the FML bus, render/overlay events on the Forge bus
        FMLCommonHandler.instance().bus().register(this);
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent ev) {
        if (ev.phase != TickEvent.Phase.END) return;
        SolverController sc = SolverController.I;
        if (mc.thePlayer == null || mc.theWorld == null) {
            if (sc.isRunning()) sc.state = SolverController.State.IDLE;
            return;
        }

        boolean screenOpen = mc.currentScreen != null;
        // always drain key presses so none pile up while a menu is open
        boolean gui = false, toggle = false, goal = false;
        while (guiKey.isPressed()) gui = true;
        while (toggleKey.isPressed()) toggle = true;
        while (goalKey.isPressed()) goal = true;

        if (!screenOpen) {
            if (gui) mc.displayGuiScreen(new MazeGui());
            if (toggle) sc.toggle();
            if (goal) {
                MovingObjectPosition hit = mc.objectMouseOver;
                if (hit != null && hit.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK)
                    sc.setGoal(hit.getBlockPos());
            }
        }
        sc.tick();
    }

    /** Small HUD readout while solving. */
    @SubscribeEvent
    public void onHud(RenderGameOverlayEvent.Post ev) {
        if (ev.type != RenderGameOverlayEvent.ElementType.TEXT) return;
        SolverController sc = SolverController.I;
        if (!sc.isRunning() || mc.currentScreen != null) return;
        String s = "\u00a7bMaze Solver\u00a7r  " + Math.min(sc.index, sc.path.size()) + "/" + sc.path.size();
        mc.fontRendererObj.drawStringWithShadow(s, 6, 6, 0xFFFFFF);
    }

    /** A* over "standing positions" (feet block): flat moves, 1-block step-ups, drops up to 3. */
    public static final class PathFinder {
        private static final int MAX_NODES = 40000;
        private static final int MAX_RANGE = 128;
        private static final int MAX_DROP = 3;

        private static class Node {
            final BlockPos pos; final Node parent; final int g, f;
            Node(BlockPos pos, Node parent, int g, int f) { this.pos = pos; this.parent = parent; this.g = g; this.f = f; }
        }

        private PathFinder() {}

        public static List<BlockPos> find(World w, BlockPos start, BlockPos goal) {
            PriorityQueue<Node> open = new PriorityQueue<Node>(64, new Comparator<Node>() {
                public int compare(Node a, Node b) { return Integer.compare(a.f, b.f); }
            });
            Map<BlockPos, Integer> best = new HashMap<BlockPos, Integer>();
            open.add(new Node(start, null, 0, heuristic(start, goal)));
            best.put(start, 0);
            int expanded = 0;

            while (!open.isEmpty() && expanded++ < MAX_NODES) {
                Node cur = open.poll();
                Integer known = best.get(cur.pos);
                if (known != null && cur.g > known) continue;
                if (isGoal(cur.pos, goal)) return reconstruct(cur);

                for (BlockPos next : neighbors(w, cur.pos)) {
                    if (Math.abs(next.getX() - start.getX()) > MAX_RANGE
                            || Math.abs(next.getZ() - start.getZ()) > MAX_RANGE) continue;
                    int g = cur.g + 1 + Math.abs(next.getY() - cur.pos.getY());
                    Integer old = best.get(next);
                    if (old == null || g < old) {
                        best.put(next, g);
                        open.add(new Node(next, cur, g, g + heuristic(next, goal)));
                    }
                }
            }
            return new ArrayList<BlockPos>(); // no path
        }

        private static boolean isGoal(BlockPos p, BlockPos goal) {
            int dh = Math.abs(p.getX() - goal.getX()) + Math.abs(p.getZ() - goal.getZ());
            int dy = p.getY() - goal.getY();
            return dh <= 1 && dy >= 0 && dy <= 1;
        }

        private static int heuristic(BlockPos a, BlockPos b) {
            return Math.abs(a.getX() - b.getX()) + Math.abs(a.getY() - b.getY()) + Math.abs(a.getZ() - b.getZ());
        }

        private static List<BlockPos> reconstruct(Node n) {
            LinkedList<BlockPos> out = new LinkedList<BlockPos>();
            for (; n.parent != null; n = n.parent) out.addFirst(n.pos);
            return out;
        }

        private static List<BlockPos> neighbors(World w, BlockPos pos) {
            List<BlockPos> out = new ArrayList<BlockPos>(4);
            for (EnumFacing d : EnumFacing.Plane.HORIZONTAL.facings()) {
                BlockPos n = pos.offset(d);
                if (!w.isBlockLoaded(n)) continue;

                if (free(w, n) && free(w, n.up())) {
                    // flat move or drop
                    BlockPos c = n;
                    for (int drop = 0; drop <= MAX_DROP; drop++) {
                        if (solidFloor(w, c)) { out.add(c); break; }
                        BlockPos below = c.down();
                        if (!free(w, below)) break;
                        c = below;
                    }
                } else if (free(w, pos.up(2)) && standable(w, n.up())) {
                    // step up one block
                    out.add(n.up());
                }
            }
            return out;
        }

        private static boolean standable(World w, BlockPos p) {
            return free(w, p) && free(w, p.up()) && solidFloor(w, p);
        }

        public static boolean free(World w, BlockPos p) {
            Block b = w.getBlockState(p).getBlock();
            return b.getCollisionBoundingBox(w, p, w.getBlockState(p)) == null && !dangerous(b);
        }

        public static boolean solidFloor(World w, BlockPos p) {
            Block b = w.getBlockState(p.down()).getBlock();
            return b.isFullCube() && b.getMaterial().blocksMovement() && !dangerous(b);
        }

        private static boolean dangerous(Block b) {
            Material m = b.getMaterial();
            return m == Material.lava || m == Material.fire
                    || b == Blocks.cactus || b == Blocks.web;
        }
    }

    /** All solver state + logic. The GUI and HUD only read from / call into this. */
    public static final class SolverController {
        public static final SolverController I = new SolverController();

        public enum State { IDLE, RUNNING, DONE, FAILED }

        // preview colours (ARGB)
        public static final int C_UNLOADED = 0xFF111111, C_WALL = 0xFF3B3B3B, C_FLOOR = 0xFF8A8A8A, C_PIT = 0xFF5A2A2A;

        private static final int SCAN_RADIUS = 48, MAX_REPATHS = 5, MAX_GRID = 160;

        private final Minecraft mc = Minecraft.getMinecraft();

        public BlockPos goal, startPos;
        public List<BlockPos> path = new ArrayList<BlockPos>();
        public int index;
        public State state = State.IDLE;
        public String status = "Idle";

        // top-down preview snapshot: gw x gh cells starting at world (gx, gz)
        public int[] grid = new int[0];
        public int gx, gz, gw, gh;

        private int stuckTicks, repaths, tick;
        private double lastX, lastY, lastZ;

        private SolverController() {}

        public boolean isRunning() { return state == State.RUNNING; }

        // ---------- public actions ----------

        public void setGoal(BlockPos pos) {
            goal = pos;
            path = new ArrayList<BlockPos>();
            index = 0;
            state = State.IDLE;
            status = "Goal set";
            buildPreview();
            chat("Goal set to " + pos.getX() + ", " + pos.getY() + ", " + pos.getZ());
        }

        public boolean autoFindGoal() {
            BlockPos found = findExitBlock();
            if (found == null) { status = "No exit block found"; return false; }
            setGoal(found);
            return true;
        }

        /** Plan the route and show it in the preview, without walking. */
        public void preview() {
            if (isRunning()) return;
            if (goal == null && !autoFindGoal()) { state = State.FAILED; return; }
            if (plan()) { state = State.IDLE; status = "Route found: " + path.size() + " steps"; }
            else { state = State.FAILED; status = "No path found"; }
        }

        public void start() {
            if (goal == null && !autoFindGoal()) {
                state = State.FAILED;
                chat("No goal. Look at the exit and press G, or place an emerald/gold/diamond block.");
                return;
            }
            repaths = 0;
            if (!plan()) { state = State.FAILED; status = "No path found"; chat(status); return; }
            state = State.RUNNING;
            status = "Solving...";
            chat("Solving... " + path.size() + " steps.");
        }

        public void stop(State newState, String message) {
            state = newState;
            status = message;
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), false);
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), false);
            chat(message);
        }

        public void toggle() {
            if (isRunning()) stop(State.IDLE, "Stopped.");
            else start();
        }

        // ---------- planning ----------

        private BlockPos playerBlock() {
            EntityPlayerSP p = mc.thePlayer;
            return new BlockPos(MathHelper.floor_double(p.posX), MathHelper.floor_double(p.posY + 0.01), MathHelper.floor_double(p.posZ));
        }

        private boolean plan() {
            startPos = playerBlock();
            path = PathFinder.find(mc.theWorld, startPos, goal);
            index = 0;
            stuckTicks = 0;
            buildPreview();
            return !path.isEmpty();
        }

        private boolean isExitBlock(Block b) {
            return b == Blocks.emerald_block || b == Blocks.gold_block || b == Blocks.diamond_block;
        }

        private BlockPos findExitBlock() {
            if (mc.thePlayer == null) return null;
            BlockPos o = playerBlock(), best = null;
            double bestD = Double.MAX_VALUE;
            for (int dx = -SCAN_RADIUS; dx <= SCAN_RADIUS; dx++)
                for (int dz = -SCAN_RADIUS; dz <= SCAN_RADIUS; dz++)
                    for (int dy = -16; dy <= 16; dy++) {
                        BlockPos p = new BlockPos(o.getX() + dx, o.getY() + dy, o.getZ() + dz);
                        if (!mc.theWorld.isBlockLoaded(p)) continue;
                        if (isExitBlock(mc.theWorld.getBlockState(p).getBlock())) {
                            double d = p.distanceSq(o);
                            if (d < bestD) { bestD = d; best = p; }
                        }
                    }
            return best;
        }

        /** Snapshot walls/floors around the route into a small colour grid for the GUI. */
        private void buildPreview() {
            World w = mc.theWorld;
            BlockPos s = startPos != null ? startPos : playerBlock();
            int minX = s.getX(), maxX = minX, minZ = s.getZ(), maxZ = minZ;
            for (BlockPos p : path) {
                minX = Math.min(minX, p.getX()); maxX = Math.max(maxX, p.getX());
                minZ = Math.min(minZ, p.getZ()); maxZ = Math.max(maxZ, p.getZ());
            }
            int pad = path.isEmpty() ? 12 : 3;
            minX -= pad; maxX += pad; minZ -= pad; maxZ += pad;
            if (maxX - minX + 1 > MAX_GRID) { minX = s.getX() - MAX_GRID / 2; maxX = minX + MAX_GRID - 1; }
            if (maxZ - minZ + 1 > MAX_GRID) { minZ = s.getZ() - MAX_GRID / 2; maxZ = minZ + MAX_GRID - 1; }

            gx = minX; gz = minZ; gw = maxX - minX + 1; gh = maxZ - minZ + 1;
            grid = new int[gw * gh];
            int refY = s.getY();
            for (int z = 0; z < gh; z++)
                for (int x = 0; x < gw; x++) {
                    BlockPos a = new BlockPos(gx + x, refY, gz + z);
                    int c;
                    if (!w.isBlockLoaded(a)) c = C_UNLOADED;
                    else if (!PathFinder.free(w, a) || !PathFinder.free(w, a.up())) c = C_WALL;
                    else if (!PathFinder.solidFloor(w, a)) c = C_PIT;
                    else c = C_FLOOR;
                    grid[z * gw + x] = c;
                }
        }

        // ---------- per-tick walking ----------

        public void tick() {
            if (state != State.RUNNING) return;
            EntityPlayerSP p = mc.thePlayer;
            tick++;

            if (index >= path.size()) { stop(State.DONE, "Reached the exit!"); return; }

            BlockPos target = path.get(index);
            double dx = target.getX() + 0.5 - p.posX;
            double dz = target.getZ() + 0.5 - p.posZ;
            double dy = target.getY() - p.posY;
            double horiz = Math.sqrt(dx * dx + dz * dz);

            if (horiz < 0.25 && Math.abs(dy) < 1.2) { index++; stuckTicks = 0; return; }

            float wanted = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
            float diff = MathHelper.wrapAngleTo180_float(wanted - p.rotationYaw);
            p.rotationYaw += MathHelper.clamp_float(diff, -35f, 35f);

            KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), Math.abs(diff) < 50f);
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), dy > 0.5 && p.onGround);

            double moved = sq(p.posX - lastX) + sq(p.posY - lastY) + sq(p.posZ - lastZ);
            if (moved < 0.0004) stuckTicks++; else stuckTicks = 0;
            lastX = p.posX; lastY = p.posY; lastZ = p.posZ;
            if (stuckTicks > 30) {
                if (++repaths > MAX_REPATHS || !plan()) stop(State.FAILED, "Got stuck - stopping.");
                return;
            }

            if (tick % 10 == 0 && mc.currentScreen == null) {
                for (int i = index; i < path.size(); i++) {
                    BlockPos b = path.get(i);
                    mc.theWorld.spawnParticle(EnumParticleTypes.VILLAGER_HAPPY, b.getX() + 0.5, b.getY() + 0.3, b.getZ() + 0.5, 0, 0, 0);
                }
            }
        }

        private static double sq(double v) { return v * v; }

        private void chat(String s) {
            if (mc.thePlayer != null) mc.thePlayer.addChatMessage(new ChatComponentText("\u00a7b[MazeSolver]\u00a7r " + s));
        }
    }

    public static class MazeGui extends GuiScreen {
        private static final int PANEL = 176;
        private static final int C_PATH = 0xFF00E5FF, C_WALKED = 0xFF00C853, C_GOAL = 0xFFFF1744,
                C_START = 0xFFFFD600, C_PLAYER = 0xFFFFFFFF;

        private final SolverController sc = SolverController.I;
        private BlockPos lookedAt;
        private GuiButton toggleBtn, previewBtn, goalBtn, autoBtn, closeBtn;
        private int left, top;

        @Override
        public void initGui() {
            MovingObjectPosition hit = mc.objectMouseOver;
            if (lookedAt == null && hit != null && hit.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK)
                lookedAt = hit.getBlockPos();

            left = width / 2 - 150;
            top = height / 2 - 105;
            buttonList.clear();
            toggleBtn  = new GuiButton(0, left, top + 30,  110, 20, "");
            previewBtn = new GuiButton(1, left, top + 54,  110, 20, "Preview Route");
            goalBtn    = new GuiButton(2, left, top + 78,  110, 20, "Set Goal: Looked-At");
            autoBtn    = new GuiButton(3, left, top + 102, 110, 20, "Auto-Find Exit");
            closeBtn   = new GuiButton(4, left, top + 126, 110, 20, "Close");
            buttonList.add(toggleBtn); buttonList.add(previewBtn); buttonList.add(goalBtn);
            buttonList.add(autoBtn);   buttonList.add(closeBtn);
            refreshButtons();
        }

        private void refreshButtons() {
            toggleBtn.displayString = "Solver: " + (sc.isRunning()
                    ? EnumChatFormatting.GREEN + "ON" : EnumChatFormatting.RED + "OFF");
            previewBtn.enabled = !sc.isRunning();
            goalBtn.enabled = lookedAt != null && !sc.isRunning();
            autoBtn.enabled = !sc.isRunning();
        }

        @Override
        protected void actionPerformed(GuiButton b) throws IOException {
            switch (b.id) {
                case 0: sc.toggle(); break;
                case 1: sc.preview(); break;
                case 2: if (lookedAt != null) sc.setGoal(lookedAt); break;
                case 3: sc.autoFindGoal(); break;
                case 4: mc.displayGuiScreen(null); break;
            }
            refreshButtons();
        }

        @Override
        public void updateScreen() { refreshButtons(); }

        @Override
        public boolean doesGuiPauseGame() { return false; } // keep walking while the menu is open

        @Override
        public void drawScreen(int mx, int my, float pt) {
            drawDefaultBackground();

            int px = left + 122, py = top + 22;
            // window frame
            drawRect(left - 10, top - 10, px + PANEL + 10, top + 222, 0xCC0B0B12);
            drawRect(left - 10, top - 10, px + PANEL + 10, top - 9, 0xFF00E5FF);

            drawString(fontRendererObj, EnumChatFormatting.BOLD + "Maze Solver", left, top + 2, 0xFFFFFF);
            drawString(fontRendererObj, "RShift to open, Esc to close", left, top + 14, 0x888888);

            super.drawScreen(mx, my, pt);

            // info text under buttons
            int ty = top + 154;
            drawString(fontRendererObj, "Status: " + stateColor() + sc.status, left, ty, 0xFFFFFF);
            String g = sc.goal == null ? "none" : sc.goal.getX() + ", " + sc.goal.getY() + ", " + sc.goal.getZ();
            drawString(fontRendererObj, "Goal: \u00a77" + g, left, ty + 11, 0xFFFFFF);
            int total = sc.path.size();
            drawString(fontRendererObj, "Steps: \u00a77" + Math.min(sc.index, total) + " / " + total, left, ty + 22, 0xFFFFFF);
            if (total > 0) {
                int bw = 110, filled = bw * Math.min(sc.index, total) / total;
                drawRect(left, ty + 35, left + bw, ty + 40, 0xFF222222);
                drawRect(left, ty + 35, left + filled, ty + 40, C_WALKED);
            }

            drawPreview(px, py);

            // legend
            int ly = py + PANEL + 5;
            legend(px, ly, C_PATH, "Route");
            legend(px + 46, ly, C_WALKED, "Done");
            legend(px + 88, ly, C_GOAL, "Goal");
            legend(px + 128, ly, C_PLAYER, "You");
        }

        private String stateColor() {
            switch (sc.state) {
                case RUNNING: return EnumChatFormatting.GREEN.toString();
                case DONE:    return EnumChatFormatting.AQUA.toString();
                case FAILED:  return EnumChatFormatting.RED.toString();
                default:      return EnumChatFormatting.GRAY.toString();
            }
        }

        private void legend(int x, int y, int color, String label) {
            drawRect(x, y + 1, x + 6, y + 7, color);
            fontRendererObj.drawString(label, x + 9, y, 0xAAAAAA);
        }

        // ---------- top-down preview ----------

        private void drawPreview(int px, int py) {
            drawRect(px - 2, py - 2, px + PANEL + 2, py + PANEL + 2, 0xFF000000);
            drawRect(px, py, px + PANEL, py + PANEL, SolverController.C_UNLOADED);

            if (sc.gw == 0 || sc.gh == 0) {
                drawCenteredString(fontRendererObj, "No preview yet", px + PANEL / 2, py + PANEL / 2 - 4, 0x777777);
                return;
            }

            int cell = Math.max(1, Math.min(10, Math.min(PANEL / sc.gw, PANEL / sc.gh)));
            int ox = px + (PANEL - sc.gw * cell) / 2;
            int oy = py + (PANEL - sc.gh * cell) / 2;

            // base map, merged into horizontal runs of equal colour
            for (int z = 0; z < sc.gh; z++) {
                int x = 0;
                while (x < sc.gw) {
                    int c = sc.grid[z * sc.gw + x], x2 = x + 1;
                    while (x2 < sc.gw && sc.grid[z * sc.gw + x2] == c) x2++;
                    drawRect(ox + x * cell, oy + z * cell, ox + x2 * cell, oy + (z + 1) * cell, c);
                    x = x2;
                }
            }

            // route: walked part green, remaining cyan
            List<BlockPos> path = sc.path;
            for (int i = 0; i < path.size(); i++)
                cell(ox, oy, cell, path.get(i), i < sc.index ? C_WALKED : C_PATH, 0);
            if (sc.startPos != null) cell(ox, oy, cell, sc.startPos, C_START, 0);
            if (sc.goal != null) cell(ox, oy, cell, sc.goal, C_GOAL, 1);

            // player marker (blinks)
            if (mc.thePlayer != null && (System.currentTimeMillis() / 350) % 2 == 0) {
                int cx = MathHelper.floor_double(mc.thePlayer.posX), cz = MathHelper.floor_double(mc.thePlayer.posZ);
                cell(ox, oy, cell, new BlockPos(cx, 0, cz), C_PLAYER, 1);
            }

            fontRendererObj.drawString("N", px + PANEL - 8, py + 2, 0xFFFFFF);
        }

        /** Draws one world column as a cell; grow makes the marker a little bigger so it stays visible. */
        private void cell(int ox, int oy, int cell, BlockPos p, int color, int grow) {
            int cx = p.getX() - sc.gx, cz = p.getZ() - sc.gz;
            if (cx < 0 || cz < 0 || cx >= sc.gw || cz >= sc.gh) return;
            int size = Math.max(cell, 2);
            int x = ox + cx * cell - (size - cell) / 2 - grow, y = oy + cz * cell - (size - cell) / 2 - grow;
            drawRect(x, y, x + size + grow * 2, y + size + grow * 2, color);
        }
    }
}
